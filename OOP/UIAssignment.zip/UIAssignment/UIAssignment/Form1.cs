﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlyingVehicleMidterm;

namespace UIAssignment
{
    public partial class Form1 : Form
    {

        AerialVehicle av; // Declare Containment test erial Vehicle

        public Form1()
        {
            InitializeComponent();
            av = new Helicopter(); // Initialize
            UpdateTextBoxAboutUI();
        }

        private void button_About_Click(object sender, EventArgs e)
        {
            UpdateTextBoxAboutUI();
        }

        void UpdateTextBoxAboutUI()
        {
            textBoxAbout.Text = av.About();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            av.StartEngine();
            UpdateTextBoxAboutUI();
        }

        private void buttonTakeOff_Click(object sender, EventArgs e)
        {
            av.TakeOff();
            UpdateTextBoxAboutUI();
        }

        private void buttonFlyUp_Click(object sender, EventArgs e)
        {
            av.FlyUp();
            UpdateTextBoxAboutUI();
        }

        private void buttonFlyDown_Click(object sender, EventArgs e)
        {
            av.FlyDown();
            UpdateTextBoxAboutUI();
        }

        private void comboBoxVehicle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxVehicle.SelectedItem.ToString())
            {
                case "Airplane":
                    av = new Airplane();
                    break;
                case "Helicopter":
                    av = new Helicopter();
                    break;
                default:
                    av = new Airplane();
                    break;
            }

            UpdateTextBoxAboutUI();
        }
    }
}
