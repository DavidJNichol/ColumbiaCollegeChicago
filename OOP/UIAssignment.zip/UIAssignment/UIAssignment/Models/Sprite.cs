﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIAssignment.Models
{
    public class Sprite
    {
        public Point Location;

        public string picure;
        public PictureBox Pb;

        public static indexer SpriteCount;

        public Sprite()
        {

        }
    }
}
